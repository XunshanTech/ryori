
var keyMirror = require('keymirror');

module.exports = keyMirror({
  ARTICLE_CHECK: null
});
