highcharts-release
=================

Official shim repo for Highcharts releases

This repo only reflects official versions of Highcharts. For bug reporting, please use the [highcharts.com](https://github.com/highslide-software/highcharts.com) working repo.
