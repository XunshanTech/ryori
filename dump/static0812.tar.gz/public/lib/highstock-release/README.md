highstock-release
=================

Official shim repo for Highstock releases

This repo only reflects official versions of Highstock. For bug reporting, please use the [highcharts.com](https://github.com/highslide-software/highcharts.com) working repo.
